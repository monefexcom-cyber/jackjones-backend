const nodemailer = require('nodemailer');

function getTransporter() {
  if (!process.env.SMTP_EMAIL || process.env.SMTP_EMAIL === 'jouwemail@gmail.com') {
    // Demo mode - log to console
    return null;
  }
  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.SMTP_EMAIL,
      pass: process.env.SMTP_PASSWORD
    }
  });
}

function formatItems(items) {
  return items.map(i => `${i.emoji || '🍕'} ${i.naam || i.name} x${i.aantal || i.qty} — €${((i.prijs || i.price) * (i.aantal || i.qty)).toFixed(2).replace('.', ',')}`).join('\n');
}

function formatItemsHTML(items) {
  return items.map(i => `
    <tr>
      <td style="padding:8px 12px;border-bottom:1px solid #eee">${i.emoji || '🍕'} ${i.naam || i.name}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:center">${i.aantal || i.qty}x</td>
      <td style="padding:8px 12px;border-bottom:1px solid #eee;text-align:right;color:#E8150A;font-weight:700">€${((i.prijs || i.price) * (i.aantal || i.qty)).toFixed(2).replace('.', ',')}</td>
    </tr>
  `).join('');
}

module.exports = {
  async stuurBevestiging({ bestellingId, naam, email, items, totaal, type, adres }) {
    const transporter = getTransporter();
    
    const html = `
      <!DOCTYPE html>
      <html><head><meta charset="UTF-8"></head>
      <body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,sans-serif">
        <div style="max-width:600px;margin:0 auto;background:white">
          <div style="background:#E8150A;padding:2rem;text-align:center">
            <h1 style="color:white;font-family:Impact,sans-serif;font-size:2rem;margin:0;letter-spacing:.1em">JACK & JONES PIZZA</h1>
            <p style="color:rgba(255,255,255,.8);margin:.5rem 0 0;font-size:.9rem">Amsterdam · Sloterdijk</p>
          </div>
          <div style="padding:2rem">
            <h2 style="color:#111;margin-bottom:.5rem">Bestelling bevestigd! ✅</h2>
            <p style="color:#666;margin-bottom:1.5rem">Hoi ${naam}, we hebben je bestelling ontvangen.</p>
            <div style="background:#f9f9f9;border-left:4px solid #E8150A;padding:1rem 1.5rem;margin-bottom:1.5rem">
              <strong style="font-size:.8rem;letter-spacing:.1em;text-transform:uppercase;color:#E8150A">Bestelnummer</strong><br>
              <span style="font-size:1.5rem;font-weight:700;color:#111">#${bestellingId}</span>
            </div>
            <table style="width:100%;border-collapse:collapse;margin-bottom:1.5rem">
              <thead><tr style="background:#111"><th style="padding:10px 12px;color:white;text-align:left">Gerecht</th><th style="padding:10px 12px;color:white;text-align:center">Aantal</th><th style="padding:10px 12px;color:white;text-align:right">Prijs</th></tr></thead>
              <tbody>${formatItemsHTML(items)}</tbody>
              <tfoot>
                <tr style="background:#f9f9f9"><td colspan="2" style="padding:10px 12px;font-weight:700">TOTAAL</td><td style="padding:10px 12px;text-align:right;color:#E8150A;font-weight:700;font-size:1.1rem">€${totaal.toFixed(2).replace('.', ',')}</td></tr>
              </tfoot>
            </table>
            <div style="background:#f9f9f9;padding:1rem 1.5rem;margin-bottom:1.5rem">
              <strong style="font-size:.8rem;letter-spacing:.1em;text-transform:uppercase;color:#666">Type</strong><br>
              <span style="font-size:1rem;color:#111">${type === 'bezorgen' ? `🛵 Bezorgen naar ${adres}` : '🏪 Afhalen: Poortland 214, Amsterdam'}</span>
            </div>
            <p style="color:#666;font-size:.88rem">We zijn bereikbaar op <strong>06 854 21 168</strong> voor vragen.</p>
          </div>
          <div style="background:#111;padding:1.5rem;text-align:center">
            <p style="color:rgba(255,255,255,.5);font-size:.78rem;margin:0">Jack & Jones Pizza · Poortland 214 · 1046 BD Amsterdam · 100% Halal</p>
          </div>
        </div>
      </body></html>
    `;

    if (!transporter) {
      console.log(`📧 [DEMO] Bevestiging naar ${email}: Bestelling #${bestellingId}`);
      return;
    }

    await transporter.sendMail({
      from: `"Jack & Jones Pizza" <${process.env.SMTP_EMAIL}>`,
      to: email,
      subject: `✅ Bestelling #${bestellingId} bevestigd - Jack & Jones Pizza`,
      html
    });
  },

  async stuurRestaurantNotificatie({ bestellingId, naam, email, telefoon, items, totaal, type, adres, postcode, opmerking }) {
    const transporter = getTransporter();
    
    const text = `
🍕 NIEUWE BESTELLING #${bestellingId}

Klant: ${naam}
Email: ${email}
Tel: ${telefoon || 'niet opgegeven'}
Type: ${type === 'bezorgen' ? `BEZORGEN → ${adres} ${postcode}` : 'AFHALEN'}

BESTELLING:
${formatItems(items)}

TOTAAL: €${totaal.toFixed(2).replace('.', ',')}
${opmerking ? `\nOpmerking: ${opmerking}` : ''}

Dashboard: ${process.env.BASE_URL}/dashboard
    `;

    if (!transporter) {
      console.log('📧 [DEMO] Restaurant notificatie:');
      console.log(text);
      return;
    }

    await transporter.sendMail({
      from: `"Jack & Jones Bestelssysteem" <${process.env.SMTP_EMAIL}>`,
      to: process.env.RESTAURANT_EMAIL,
      subject: `🍕 NIEUWE BESTELLING #${bestellingId} — €${totaal.toFixed(2).replace('.', ',')} (${type})`,
      text
    });
  }
};
