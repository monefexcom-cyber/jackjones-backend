# Jack & Jones Pizza — Bestelssysteem

## Setup

### 1. Installeer dependencies
```
npm install
```

### 2. Maak .env bestand
```
cp .env.example .env
```
Vul in:
- `MOLLIE_API_KEY` — via mollie.com (gratis account)
- `RESTAURANT_EMAIL` — email van het restaurant
- `SMTP_EMAIL` + `SMTP_PASSWORD` — Gmail voor versturen emails
- `BASE_URL` — jouw Railway URL
- `DASHBOARD_TOKEN` — zelf verzinnen wachtwoord voor dashboard

### 3. Start lokaal
```
npm start
```

## Deploy op Railway
1. Ga naar railway.app
2. "New Project" → "Deploy from GitHub"
3. Upload deze map
4. Voeg environment variables toe
5. Klaar!

## URLs
- `GET /` — website
- `GET /dashboard` — restaurant dashboard
- `POST /api/bestellingen` — nieuwe bestelling
- `GET /api/bestellingen` — alle bestellingen
- `PATCH /api/bestellingen/:id/status` — status updaten
- `POST /api/webhook/mollie` — Mollie webhook
