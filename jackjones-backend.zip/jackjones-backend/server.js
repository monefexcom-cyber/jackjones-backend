require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('./database');
const mailer = require('./mailer');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

// ── MOLLIE ──
let mollieClient = null;
try {
  if (process.env.MOLLIE_API_KEY && process.env.MOLLIE_API_KEY !== 'test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx') {
    const { createMollieClient } = require('@mollie/api-client');
    mollieClient = createMollieClient({ apiKey: process.env.MOLLIE_API_KEY });
    console.log('✅ Mollie gekoppeld');
  } else {
    console.log('⚠️  Mollie niet geconfigureerd — gebruik demo modus');
  }
} catch(e) {
  console.log('⚠️  Mollie niet beschikbaar:', e.message);
}

// ════════════════════════════════════
// API ROUTES
// ════════════════════════════════════

// GET /api/status — health check
app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'ok', 
    restaurant: 'Jack & Jones Pizza Amsterdam',
    mollie: mollieClient ? 'connected' : 'demo',
    timestamp: new Date().toISOString()
  });
});

// POST /api/bestellingen — nieuwe bestelling aanmaken
app.post('/api/bestellingen', async (req, res) => {
  try {
    const { naam, email, telefoon, adres, postcode, type, items, opmerking } = req.body;

    // Validatie
    if (!naam || !email || !items || items.length === 0) {
      return res.status(400).json({ error: 'Naam, email en items zijn verplicht' });
    }

    // Bereken totaal
    const subtotaal = items.reduce((s, i) => s + (i.prijs * i.aantal), 0);
    const bezorgkosten = type === 'bezorgen' ? 2.50 : 0;
    const totaal = subtotaal + bezorgkosten;

    // Maak bestelling aan
    const bestellingId = uuidv4().substring(0, 8).toUpperCase();
    
    db.maakBestelling({
      id: bestellingId,
      naam, email, telefoon,
      adres: adres || '',
      postcode: postcode || '',
      type: type || 'afhalen',
      items: JSON.stringify(items),
      subtotaal, bezorgkosten, totaal,
      opmerking: opmerking || '',
      status: mollieClient ? 'wacht_betaling' : 'nieuw',
      betaalmethode: mollieClient ? 'ideal' : 'contant'
    });

    // Als Mollie beschikbaar: maak betaallink aan
    if (mollieClient) {
      try {
        const betaling = await mollieClient.payments.create({
          amount: { currency: 'EUR', value: totaal.toFixed(2) },
          description: `Jack & Jones Pizza - Bestelling #${bestellingId}`,
          redirectUrl: `${BASE_URL}/bedankt?id=${bestellingId}`,
          webhookUrl: `${BASE_URL}/api/webhook/mollie`,
          metadata: { bestellingId }
        });

        db.updateBetalingId(bestellingId, betaling.id);
        
        return res.json({
          success: true,
          bestellingId,
          betaalUrl: betaling.getCheckoutUrl(),
          mollie: true
        });
      } catch(mollieErr) {
        console.error('Mollie error:', mollieErr.message);
      }
    }

    // Geen Mollie: stuur email bevestiging direct
    await mailer.stuurBevestiging({ bestellingId, naam, email, items, totaal, type, adres });
    await mailer.stuurRestaurantNotificatie({ bestellingId, naam, email, telefoon, items, totaal, type, adres, postcode, opmerking });

    res.json({
      success: true,
      bestellingId,
      betaalUrl: null,
      mollie: false,
      message: 'Bestelling ontvangen! Je krijgt een bevestiging per email.'
    });

  } catch(err) {
    console.error('Bestelling error:', err);
    res.status(500).json({ error: 'Er ging iets mis. Probeer opnieuw.' });
  }
});

// POST /api/webhook/mollie — Mollie betaalstatus update
app.post('/api/webhook/mollie', async (req, res) => {
  try {
    if (!mollieClient) return res.status(200).send('ok');
    
    const { id } = req.body;
    const betaling = await mollieClient.payments.get(id);
    const bestellingId = betaling.metadata?.bestellingId;
    
    if (!bestellingId) return res.status(200).send('ok');

    if (betaling.status === 'paid') {
      db.updateStatus(bestellingId, 'betaald');
      const bestelling = db.getBestelling(bestellingId);
      if (bestelling) {
        const items = JSON.parse(bestelling.items);
        await mailer.stuurBevestiging({ bestellingId, naam: bestelling.naam, email: bestelling.email, items, totaal: bestelling.totaal, type: bestelling.type, adres: bestelling.adres });
        await mailer.stuurRestaurantNotificatie({ bestellingId, ...bestelling, items });
      }
    } else if (betaling.status === 'failed' || betaling.status === 'canceled') {
      db.updateStatus(bestellingId, 'mislukt');
    }

    res.status(200).send('ok');
  } catch(err) {
    console.error('Webhook error:', err);
    res.status(200).send('ok');
  }
});

// GET /api/bestellingen — alle bestellingen (dashboard)
app.get('/api/bestellingen', (req, res) => {
  const { token } = req.query;
  if (token !== process.env.DASHBOARD_TOKEN && process.env.DASHBOARD_TOKEN) {
    return res.status(401).json({ error: 'Geen toegang' });
  }
  const bestellingen = db.getAlleBestellingen();
  res.json(bestellingen.map(b => ({ ...b, items: JSON.parse(b.items) })));
});

// PATCH /api/bestellingen/:id/status — status updaten
app.patch('/api/bestellingen/:id/status', (req, res) => {
  const { token } = req.query;
  if (token !== process.env.DASHBOARD_TOKEN && process.env.DASHBOARD_TOKEN) {
    return res.status(401).json({ error: 'Geen toegang' });
  }
  const { status } = req.body;
  db.updateStatus(req.params.id, status);
  res.json({ success: true });
});

// GET /api/bestellingen/:id — specifieke bestelling
app.get('/api/bestellingen/:id', (req, res) => {
  const bestelling = db.getBestelling(req.params.id);
  if (!bestelling) return res.status(404).json({ error: 'Niet gevonden' });
  res.json({ ...bestelling, items: JSON.parse(bestelling.items) });
});

// ── PAGINAS ──
app.get('/bedankt', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'bedankt.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🍕 Jack & Jones Pizza Backend`);
  console.log(`✅ Server draait op http://localhost:${PORT}`);
  console.log(`📊 Dashboard: http://localhost:${PORT}/dashboard`);
});
