const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'bestellingen.json');

function lees() {
  try {
    if (!fs.existsSync(DB_FILE)) return [];
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch(e) { return []; }
}

function schrijf(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

module.exports = {
  maakBestelling(data) {
    const db = lees();
    const record = { ...data, aangemaakt_op: new Date().toISOString(), bijgewerkt_op: new Date().toISOString() };
    db.unshift(record);
    schrijf(db);
    return record;
  },

  getBestelling(id) {
    return lees().find(b => b.id === id) || null;
  },

  getAlleBestellingen() {
    return lees();
  },

  updateStatus(id, status) {
    const db = lees();
    const idx = db.findIndex(b => b.id === id);
    if (idx > -1) {
      db[idx].status = status;
      db[idx].bijgewerkt_op = new Date().toISOString();
      schrijf(db);
    }
  },

  updateBetalingId(id, betalingId) {
    const db = lees();
    const idx = db.findIndex(b => b.id === id);
    if (idx > -1) {
      db[idx].betaling_id = betalingId;
      schrijf(db);
    }
  },

  getStats() {
    const db = lees();
    const vandaag = new Date().toDateString();
    const vandaagItems = db.filter(b => new Date(b.aangemaakt_op).toDateString() === vandaag && !['mislukt','geannuleerd'].includes(b.status));
    return {
      totaal: { count: db.length, omzet: db.reduce((s,b) => s + (b.totaal||0), 0) },
      vandaag: { count: vandaagItems.length, omzet: vandaagItems.reduce((s,b) => s + (b.totaal||0), 0) }
    };
  }
};
